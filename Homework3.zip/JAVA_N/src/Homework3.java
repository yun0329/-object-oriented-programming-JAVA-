import java.util.Scanner;

public class Homework3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // 몇 개의 정수를 입력받을 것인지 먼저 입력받음
        System.out.print("몇 개의 수를 입력할 예정인가요? ");
        int count = scanner.nextInt();
        
        // 입력받은 정수를 저장할 배열 생성
        int[] numbers = new int[count];
        
        // 정수를 배열에 저장
        System.out.print("수를 입력하세요. ");
        for (int i = 0; i < count; i++) {
            numbers[i] = scanner.nextInt();
        }
        
        // 최소값과 최대값 초기화
        int minValue = numbers[0];
        int maxValue = numbers[0];
        
        // 배열에서 최소값과 최대값 찾기
        for (int i = 1; i < count; i++) {
            if (numbers[i] < minValue) {
                minValue = numbers[i];
            }
            if (numbers[i] > maxValue) {
                maxValue = numbers[i];
            }
        }
        
        // 최소값과 최대값 출력
        System.out.println("최대값: " + maxValue);
        System.out.println("최소값: " + minValue);
      
        
        // 스캐너 닫기
        scanner.close();
    }
}
