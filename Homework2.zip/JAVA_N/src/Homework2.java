import java.util.Scanner;

class Student {
    private int studentNumber;
    private String name;
    private String major;
    private String phoneNumber;

  
    public int getStudentNumber() {
        return studentNumber;
    }

    public void setStudentNumber(int studentNumber) {
        this.studentNumber = studentNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        
    	 phoneNumber = phoneNumber.replaceAll("[^0-9]", "");
         phoneNumber = phoneNumber.replaceFirst("(\\d{3})(\\d{4})(\\d+)", "010-$2-$3");
         this.phoneNumber = phoneNumber;
    }
}

public class Homework2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Student[] students = new Student[3];

       
        for (int i = 0; i < 3; i++) {
            System.out.print("학생의 학번, 이름, 전공, 전화번호를 입력하세요: ");
            int studentNumber = scanner.nextInt();
   
            String name = scanner.next();
            String major = scanner.next();
            String phoneNumber = scanner.next();

          
            studentNumber = Integer.parseInt(String.valueOf(studentNumber));
            phoneNumber = phoneNumber.replaceFirst("^0+", "");

     
            Student student = new Student();
            student.setStudentNumber(studentNumber);
            student.setName(name);
            student.setMajor(major);
            student.setPhoneNumber(phoneNumber);

            students[i] = student;
        }

        System.out.println("입력된 학생들의 정보는 다음과 같습니다.");
     
            System.out.println("첫번째 학생: " + students[1].getStudentNumber() +
                    " " + students[0].getName() +
                    " " + students[0].getMajor() +
                    " " + students[0].getPhoneNumber());
            System.out.println("두번째 학생: " + students[1].getStudentNumber() +
                    " " + students[1].getName() +
                    " " + students[1].getMajor() +
                    " " + students[1].getPhoneNumber());
            System.out.println("세번째 학생: " + students[1].getStudentNumber() +
                    " " + students[2].getName() +
                    " " + students[2].getMajor() +
                    " " + students[2].getPhoneNumber());
        
        
    }
}

